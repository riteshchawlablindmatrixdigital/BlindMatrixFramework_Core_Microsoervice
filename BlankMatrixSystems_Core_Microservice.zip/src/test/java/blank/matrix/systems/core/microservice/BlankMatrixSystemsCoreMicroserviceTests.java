package blank.matrix.systems.core.microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlankMatrixSystemsCoreMicroserviceTests {

    @Test
    void contextLoads() {
    }

}
