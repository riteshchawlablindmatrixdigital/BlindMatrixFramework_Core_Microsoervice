package blind.matrix.systems.core.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlindMatrixFrameworkCoreSystemsAppnApplicationTests {

    @Test
    void contextLoads() {
    }

}
